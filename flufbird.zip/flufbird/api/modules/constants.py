from datetime import timedelta

CREDENTIALS = {
    "length": {
        "username": [2, 32],
        "password": [8, 32],
    },
    "characters": {
        "username": "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_",
        "password": "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789~`!?@#$%^&*_+-=<>()[]{}|/\,.;:'\"",
    },
}

TOKENS = {
    "audit_log_id": 32,
    "user_cooldown_id": 64,
    "user_authorization_token": 64,
}

COOLDOWNS = {
    "log_in": timedelta(minutes=1).total_seconds(),
}

MAINTENANCE_IGNORE = (
    "/robots.txt",
)

USER_AUTHORIZATION_TOKEN_EXPIRY = 30 * 86400