from modules.functions import create_blueprint
from os import listdir
from flask import current_app

ROUTES = "routes"

v1 = create_blueprint("v1", "/v1")

v1_update = create_blueprint("v1_update", "/update")
v1_authentication = create_blueprint("v1_authentication", "/authentication")

for version in listdir(ROUTES):
    for group in listdir(f"{ROUTES}/{version}"):
        for route in listdir(f"{ROUTES}/{version}/{group}"):
            if not route.endswith(".py"):
                continue

            __import__(f"{ROUTES}.{version}.{group}.{route[:-3]}")

v1.register_blueprint(v1_update)
v1.register_blueprint(v1_authentication)

current_app.register_blueprint(v1)