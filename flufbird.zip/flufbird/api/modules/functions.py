from dotenv import load_dotenv
from modules.constants import CREDENTIALS, TOKENS, USER_AUTHORIZATION_TOKEN_EXPIRY
from modules._global import controls
from os import environ
from datetime import datetime
import secrets
import argon2
import deta
from flask import Blueprint, Response, make_response, jsonify

load_dotenv()

hasher = argon2.PasswordHasher(
    hash_len=64,
    salt_len=32,
    time_cost=1,
    memory_cost=256 * 1024,
    parallelism=8,
)

def get_environment_variable(key : str) -> str | None:
    return environ.get(key)

def get_database(name : str) -> deta._Base:
    return deta.Deta(get_environment_variable("deta_key")).Base(f'{"development_" if control["development"] else ""}{name}')

def create_blueprint(
    name : str,
    prefix : str | None = None,
) -> Blueprint:
    return Blueprint(name, __name__, url_prefix=prefix)

def get_time() -> str:
    return datetime.now().strftime("%d/%m/%Y %I:%M %p")

def generate_token(length : int, database : deta._Base) -> str | None:
    tries = 0

    while tries < 3: # this code shouldnt take over 2 tries, adding a hard limit is a better approach compared to using an infinite loop
        token = secrets.token_hex(int(length / 2))

        if not database.get(token):
            return token

        tries += 1

def validate_credentials(username : str | None, password : str | None) -> bool:
    if (
        (not username or not password) or

        (len(username) < CREDENTIALS["length"]["username"][0]) or
        (len(username) > CREDENTIALS["length"]["username"][1]) or

        (len(password) < CREDENTIALS["length"]["password"][0]) or
        (len(password) > CREDENTIALS["length"]["password"][1])
    ):
        return False

    for character in username:
        if character not in CREDENTIALS["characters"]["username"]:
            return False

    for character in password:
        if character not in CREDENTIALS["characters"]["password"]:
            return False

    return True

def _hash(string : str) -> str:
    return hasher.hash(string)

def verify_hash(string : str, hashed : str) -> bool:
    try:
        return hasher.verify(hashed, string)
    except argon2.exceptions.VerifyMismatchError:
        return False

def audit_log(
    user : str,
    action : str,
    data : dict = {},
    time : str | None = None,

    administrator : bool = False,
):
    if controls["development"]:
        return

    if not time:
        time = get_time()

    logs = get_database(f'{"administrator_" if administrator else ""}audit_logs')

    logs.put({
        "key": generate_token(TOKENS["audit_log_id"], logs),
        "user": user,
        "action": action,
        "data": data,
        "time": time,
    })

def generate_user_authorization_token(tokens : deta._Base, username : str) -> str | None:
    token = generate_token(TOKENS["user_authorization_token"], tokens)

    if not token:
        return

    tokens.put({
        "key": token,
        "user": username,
    }, expire_in=USER_AUTHORIZATION_TOKEN_EXPIRY)

    return token

def create_json_response(
    successful : bool,
    data : dict | None = None,
    error : str | None = None,
    status_code : int = 200,
) -> Response:
    return make_response(jsonify({
        "successful": successful,
        "data": data,
        "error": error,
    }), status_code)