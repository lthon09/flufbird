import json

with open("data/general.json", "r") as file:
    general = json.load(file)

with open("data/controls.json", "r") as file:
    controls = json.load(file)