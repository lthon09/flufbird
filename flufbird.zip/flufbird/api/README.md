This is the source code of FlufBird's API made with Flask.

To start the server:
1. Get [Python](https://www.python.org/downloads).
2. Create an `.env` file with the following keys:
- `deta_key`: The key of your [Deta](https://deta.sh) project.
3. Install the dependencies from `requirements.txt` (`pip install -r requirements.txt`).
4. Run `main.py`.
5. The server will be located at `http://localhost:31822`.