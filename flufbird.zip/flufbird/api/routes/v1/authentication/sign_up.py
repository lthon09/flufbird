from modules._global import controls
from modules.functions import get_database, get_time, validate_credentials, _hash, audit_log, generate_user_authorization_token, create_json_response
from modules.blueprints import v1_authentication
from flask import request

@v1_authentication.route("/sign_up", methods=["post"])
def sign_up():
    time = get_time()

    if not controls["signUp"]:
        audit_log(username, "sign_up", data={"successful": False, "error": "disabled"}, time=time)

        return create_json_response(False, error="disabled", status_code=503)

    authorization = request.authorization

    if not authorization:
        audit_log(username, "sign_up", data={"successful": False, "error": "no_authorization"}, time=time)

        return create_json_response(False, error="noAuthorization", status_code=400)

    username = authorization.username
    password = authorization.password

    _validate_credentials = validate_credentials(username, password)

    if not _validate_credentials:
        audit_log(username, "sign_up", data={"successful": False, "error": "invalid_credentials"}, time=time)

        return create_json_response(False, error="invalidCredentials", status_code=401)

    usernames = get_database("usernames")
    users = get_database("users")
    tokens = get_database("tokens")

    if usernames.get(username):
        audit_log(username, "sign_up", data={"successful": False, "error": "unavailable_username"}, time=time)

        return create_json_response(False, error="unavailableUsername", status_code=409)

    usernames.put({"key": username})

    users.put({
        "key": username,
        "settings": {
            "display_name": None,
            "bio": None,
            "password": _hash(password),
            "show": {
                "friends": True,
                "servers": True,
            },
        },
        "log_in": True,
        "created": time,
    })

    token = generate_user_authorization_token(tokens, username)

    if not token:
        audit_log(username, "sign_up", data={"successful": False, "error": "unsuccessful_token_generation"}, time=time)

        return create_json_response(False, error="unexpectedError", status_code=500)

    audit_log(username, "sign_up", data={"successful": True}, time=time)

    return create_json_response(True, data={"token": token})