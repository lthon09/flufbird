from modules.constants import TOKENS, COOLDOWNS
from modules.functions import get_database, validate_credentials, verify_hash, audit_log, generate_token, generate_user_authorization_token, create_json_response
from modules.blueprints import v1_authentication
from flask import request

@v1_authentication.route("/log_in", methods=["post"])
def log_in():
    authorization = request.authorization

    if not authorization:
        audit_log(username, "log_in", data={"successful": False, "error": "no_authorization"})

        return create_json_response(False, error="noAuthorization", status_code=400)

    username = authorization.username
    password = authorization.password

    _validate_credentials = validate_credentials(username, password)

    if not _validate_credentials:
        audit_log(username, "log_in", data={"successful": False, "error": "invalid_credentials"})

        return create_json_response(False, error="invalidCredentials", status_code=401)

    users = get_database("users")
    tokens = get_database("tokens")
    cooldowns = get_database("cooldowns")

    user = users.get(username)

    if not user["log_in"]:
        audit_log(username, "log_in", data={"successful": False, "error": "locked"})

        return create_json_response(False, error="locked", status_code=503)

    if not verify_hash(password, user["settings"]["password"]):
        audit_log(username, "log_in", data={"successful": False, "error": "incorrect_credentials"})

        return create_json_response(False, error="incorrectCredentials", status_code=403)

    if cooldowns.fetch({"user": username, "type": "log_in"}, limit=1).count:
        audit_log(username, "log_in", data={"successful": False, "error": "on_cooldown"})

        return create_json_response(False, error="onCooldown", status_code=429)

    token = generate_user_authorization_token(tokens, username)
    cooldown_id = generate_token(TOKENS["user_cooldown_id"], cooldowns)

    if not token:
        audit_log(username, "log_in", data={"successful": False, "error": "unsuccessful_token_generation"})

        return create_json_response(False, error="unexpectedError", status_code=500)

    if not cooldown_id:
        audit_log(username, "log_in", data={"successful": False, "error": "unsuccessful_cooldown_id_generation"})

        return create_json_response(False, error="unexpectedError", status_code=500)

    cooldowns.put({
        "key": cooldown_id,
        "user": username,
        "type": "log_in",
    }, expire_in=COOLDOWNS["log_in"])

    audit_log(username, "log_in", data={"successful": True})

    return create_json_response(True, data={"token": token})