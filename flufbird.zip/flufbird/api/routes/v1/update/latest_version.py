from modules._global import general
from modules.functions import create_json_response
from modules.blueprints import v1_update

@v1_update.route("/latest_version", methods=["get"])
def latest_version():
    return create_json_response(True, data={"latestVersion": general["latestVersion"]})