from modules.blueprints import v1_update

@v1_update.route("/download", methods=["get"])
def download():
    return "test" # TODO: redirect