from modules.constants import MAINTENANCE_IGNORE
from modules._global import controls
from modules.functions import create_json_response
import os
from flask import Flask, request, abort, send_from_directory

app = Flask(__name__)

app.secret_key = os.urandom(64)

@app.before_request
def before_request():
    if request.path.startswith(MAINTENANCE_IGNORE):
        return

    if controls["maintenance"]:
        return abort(create_json_response(False, error="maintenance", status_code=503))

@app.route("/check", methods=["get"]) # for status checks
def index():
    return "", 200

@app.route("/robots.txt", methods=["get"])
def robots():
    return send_from_directory("", "robots.txt")

with app.app_context():
    __import__("modules.blueprints")

if __name__ == "__main__":
    app.run(port=31822, debug=True)