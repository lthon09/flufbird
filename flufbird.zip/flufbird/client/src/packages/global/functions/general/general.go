package general

import (
	"github.com/FlufBird/client/packages/global/variables"

	"fmt"
)

func GetLanguageData(key string, arguments ...any) string { // FIXME
	return fmt.Sprintf(variables.Language.Path(key).Data().(string), arguments...)
}