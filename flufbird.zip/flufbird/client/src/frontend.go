package main

import (
	"github.com/FlufBird/client/packages/global/variables"

	. "github.com/FlufBird/client/packages/global/functions/general"
	"github.com/FlufBird/client/packages/global/functions/logging"

	"fmt"
	"context"

	"github.com/wailsapp/wails/v2/pkg/runtime"
)

type Application struct {
	context context.Context
}

func createApplication() *Application {
	return &Application{}
}

func (application *Application) onStartup(context context.Context) {
	logging.Information("Frontend", "Frontend started up.")

	application.context = context

	runtime.EventsOnce(context, "ready", func(_ ...interface{}) {
		logging.Information("Frontend", "Frontend is ready.")

		go setup(application.context)
	})
}

func setup(context context.Context) {
	runtime.EventsOnce(context, "updatesChecked", func(_ ...interface{}) {
		logging.Information("Frontend", "Updates have been checked.")

		// go updateChecker(clientVersion, fmt.Sprintf("%s/update", variables.Api))
	})

	newUpdateAvailable, latestVersion, checkUpdatesError := checkUpdates(variables.ClientVersion, fmt.Sprintf("%s/update", variables.Api))

	if checkUpdatesError != nil {
		logging.Error("Update Checker (Frontend)", "Unable to check for updates: %s", checkUpdatesError)

		runtime.EventsEmit(context, "startupUpdateCheck", []interface{}{"error"})
	} else if newUpdateAvailable {
		logging.Information("Update Checker (Frontend)", "New update available (v%s).", latestVersion)

		runtime.EventsEmit(context, "startupUpdateCheck", []interface{}{"available", latestVersion})
	} else {
		logging.Information("Update Checker (Frontend)", "Client is up-to-date (v%s).", variables.ClientVersion)
	}
}

func (application *Application) GetLanguageData_(key string, arguments ...any) string {
	return GetLanguageData(key, arguments)
}