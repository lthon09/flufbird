package main

func main() {
	startBackend()
}