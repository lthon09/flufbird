const languageElements = $("[data-language]", true);

for (let index = 0; index < languageElements.length; index++) {
    const element = languageElements[index];

    setLanguageData(element, element.dataset.language);
}

window.addEventListener("load", () => window.runtime.EventsEmit("ready"));