import {
    GetLanguageData_,
} from "../../wailsjs/go/main/Application";

window.$ = (query, _array) => {
	let results = document.querySelectorAll(query);

    if (!_array) return results[0];

    return results;
};

window.setLanguageData = (element, key, ..._arguments) =>GetLanguageData_(key, ..._arguments).then((value) => element.innerText = value);