const updateDialog = $(".update-dialog");
const updateDialogMessage = $(".update-dialog .message");

const updateDialogNoOption = $(".update-dialog .options .no");
const updateDialogYesOption = $(".update-dialog .options .yes");

runtime.EventsOnce("startupUpdateCheck", ([type, latestVersion]) => {
    updateDialog.classList.remove("hidden");

    if (!latestVersion) setLanguageData(updateDialogMessage, `update.${type}.message`);
    else setLanguageData(updateDialogMessage, `update.${type}.message`, latestVersion);

    setLanguageData(updateDialogNoOption, `update.${type}.options.no`);
    setLanguageData(updateDialogYesOption, `update.${type}.options.yes`);

    runtime.WindowCenter();
    runtime.WindowShow();
});