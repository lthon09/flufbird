const communityInvite = "flufbird";

const joinCommunity = $(".content .top .buttons .join-community", false);

joinCommunity.addEventListener("click", () => {
    if (joinCommunity.classList.contains("active") || joinCommunity.classList.contains("unsuccessful")) return;

    const unsuccessful = () => {
        joinCommunity.classList.add("unsuccessful");

        setTimeout(() => {
            joinCommunity.classList.remove("unsuccessful");
        }, 1.5 * 1000);
    };

    if (!navigator.clipboard) {
        unsuccessful();

        return;
    }

    navigator.clipboard.writeText(communityInvite).then(
        () => {
            joinCommunity.classList.add("active");

            setTimeout(() => {
                joinCommunity.classList.remove("active");
            }, 1.5 * 1000);
        },
        unsuccessful,
    );
});