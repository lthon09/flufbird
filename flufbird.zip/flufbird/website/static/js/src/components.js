const navigationBar = $(".navigation-bar", false);

const navigationBarTop = (navigationBar) ? navigationBar.children[0] : null;

const navigationBarNavigation = (navigationBar) ? navigationBar.children[1] : null;

const navigationBarToggle = (navigationBar) ? navigationBarTop.children[1] : null;

const toggleNavigationBar = (action) => {
    if (!isOnSmallScreen()) return;

    const isDropped = navigationBarNavigation.style.display == "flex";

    const close = () => navigationBarNavigation.style.display = "";
    const open = () => navigationBarNavigation.style.display = "flex";

    if (action === "close" && isDropped) {
        close();
    } else if (action === "toggle") {
        (isDropped) ? close() : open();
    }
};

if (navigationBar) {
    document.addEventListener("click", (event) => {
        if (!navigationBar.contains(event.target)) toggleNavigationBar("close");
    });

    navigationBarToggle.addEventListener("click", (_) => toggleNavigationBar("toggle"));
}