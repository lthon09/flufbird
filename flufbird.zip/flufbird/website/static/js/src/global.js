const smallScreenWidth = 950;

const $ = (query, _array) => {
	let results = document.querySelectorAll(query);

    if (!_array) return results[0];

    return results;
};

window.addEventListener("load", () => $(".container", false).style.display = "block");

const isOnSmallScreen = () => window.matchMedia(`(max-width: ${smallScreenWidth}px)`).matches;