This is the source code of FlufBird's website made with Flask.

To start the website:
1. Get [Python](https://www.python.org/downloads).
2. Build all the SCSS and JS assets (Run the script below).
3. Install the dependencies from `requirements.txt` (`pip install -r requirements.txt`).
4. Run `main.py`.
5. The website will be located at `http://localhost:22813`.

To process (Build and Minify) the SCSS and JS files, run `npm install` and `npm run build` inside `build` (Requires [Node.JS](https://nodejs.org/en/download)), this script will watch for changes for you and process the files automatically.