import json
from werkzeug.exceptions import HTTPException
from flask import Flask, render_template, send_from_directory

with open("data/errors.json", "r") as file:
    errors = json.load(file)

with open("data/announcement.json", "r") as file:
    announcement = json.load(file)["announcement"]

with open("data/navigation.json", "r") as file:
    navigation = json.load(file)

with open("data/team.json", "r") as file:
    team = json.load(file)

app = Flask(__name__)

@app.errorhandler(HTTPException)
def error_handler(error):
    code = error.code
    _code = str(code)
    __code = _code if _code in errors else "unknown"

    return render_template("error.html", code=code, name=errors[__code][0], message=errors[__code][1]), code

@app.route("/robots.txt", methods=["get"])
def robots():
    return send_from_directory("", "robots.txt")

@app.route("/", methods=["get"])
def index():
    return render_template("index.html",
        page="home",
        announcements=announcement,
        navigation=navigation,
    )

@app.route("/download", methods=["get"])
def download():
    return render_template("download.html",
        page="download",
        announcement=announcement,
        navigation=navigation,
    )

if __name__ == "__main__":
    app.run(port=22813, debug=True)